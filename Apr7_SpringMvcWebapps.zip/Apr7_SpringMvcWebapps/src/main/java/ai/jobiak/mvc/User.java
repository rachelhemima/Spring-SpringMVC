package ai.jobiak.mvc;

public class User {
private String fname;
private long mobile;
private String email;

public User() {
	// TODO Auto-generated constructor stub
}
public String getFname() {
	return fname;
}
public void setFname(String fname) {
	this.fname = fname;
}
public long getMobile() {
	return mobile;
}
public void setMobile(long mobile) {
	this.mobile = mobile;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
}
